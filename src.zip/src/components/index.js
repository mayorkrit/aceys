import MyDialog from '@/components/MyDialog'

export default [
    MyDialog
]